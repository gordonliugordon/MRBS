<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Index</title>
	<link rel="stylesheet" href="B_custom.css" type="text/css">
	<link rel="stylesheet" href="backtop.css" type="text/css">
</head>
<!--introduce users approved checkbox js-->
<script type="text/javascript" src="jquery-3.1.0.js"></script>
<script type="text/javascript" src="users_approved.js"></script>
<script type="text/javascript" src="backtop.js"></script>
<script type="text/javascript">
	$(document).ready(function () {
		var form = $('#search_form'),
			search = $('#search_text');
		
		form.submit(function (e) {
			e.preventDefault();
			var val = search.val();
			showRotate();
			search.val(val);
			$(this).unbind('submit').submit();

		});
		
		var showRotate = function () {
			search.addClass('searching').val('');
			setTimeout(function () {
				search.removeClass('searching');
			}, 3600);
			return true;
		}
	});
</script>
<body>

<div id="header">
	<a href="B_Index.php" rel="home">
		<img src="./B_img/king.png" alt="logo" class="img_logo"></a>

	<div class="menu_bar">
		<div class="header_menu">
			<a href="B_Index.php?target_page=home">Home</a></div>
		<div class="header_menu">
			<a href="B_Index.php?target_page=all">All articles</a></div>
		<?php session_start();
		if ($_SESSION["is_admin"] == 1) {
			?>
			<div class="header_menu">
				<a href="B_Index.php?target_page=users&user_info=1">List Users</a></div>
			<?php
		}
		if (isset($_SESSION["user_id"])) {
			?>
			<div class="header_menu">
				<a href="B_Index.php?target_page=my">My Article</a></div>
			<?php
		}
		?>
		<div class="header_menu">
			<a href="B_Index.php?target_page=us">About Us</a></div>
	</div>

	<div>
		<form id="search_form" name="search_form" action="" method="post">
			<input id="search_text" type="search" name="search_text" placeholder="search here"/>
			<p></p>
		</form>
	</div>

	<!-- set login info to index page,user account area -->
	<?php
	if (isset($_SESSION["user_id"])) {
		?>
		<div class="user-account-area">
			<img alt='user-account' src='./B_img/none.png' height='46' width='46'/>
			<div class="user-dropdown">
				<div>
					<?php echo $_SESSION["user_name"]; ?>
				</div>
				<div>
					<a href="./B_logout.php">Logout</a>
				</div>
			</div>
		</div>
		<?php
	} else {
		?>
		<div class="user-account-area">
			<img alt='user-account' src='./B_img/none.png' height='46' width='46'/>
			<div class="user-dropdown">
				<div>
					<a href="./B_Login.php">Login</a>
				</div>
				<div>
					<a href="./B_Login.php?action=register">Register</a>
				</div>
			</div>
		</div>
		<?php
	}
	?>
	<!-- set login info to index page-->
</div>


<div id="content">
	<?php
	include "B_blogdatabase.php";
	include "B_home_content.php";
	include "B_all_content.php";
	include "B_users_content.php";
	include "B_my_content.php";
	include "B_us_content.php";
	include "B_page.php";
	include "B_common_functions.php";
	if (empty($_POST['search_text'])) {
		$target_page = $_GET["target_page"];
		switch ($target_page) {
			case 'home':
				home_content();
				break;
			case 'all':
				all_content();
				break;
			case 'users':
				users_content();
				break;
			case 'my':
				my_content();
				break;
			case 'us':
				us_content();
				break;
			default :
				home_content();
				break;
		}
	} else {
		home_content($_POST['search_text']);
	}
	?>

</div>
	
<p id="back_top">
	<a href="#top"><span id="back_top_icon"></span>Back to Top</a>
</p>
<div id="footer">
<p>All Rights Reserved, Copyright © 2015-<?php echo date("Y")?></p>
</div>

</body>
</html>
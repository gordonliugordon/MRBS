<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	include 'B_blogdatabase.php';
	$delete_article = new Articles();
	$is_cmted = $delete_article->deleteArticle($_GET["current_delete_article_id"]);
		if ($is_cmted)
		{
			header("Location: ./B_Index.php?target_page=my");
		}
}

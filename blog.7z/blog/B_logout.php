<?php
session_start();
if(isset($_SESSION["user_id"])) {
	//clear session
	$_SESSION = [];
	//clear cookie
//	if(isset($_COOKIE[session_name()])){
//		setcookie(session_name(),"",time()-3600);
//	}
	session_destroy();
//	setcookie("user_id","",time()-3600);
//	setcookie("user_name","",time()-3600);
//	setcookie("is_admin","",time()-3600);

	$home_url = "B_Index.php";
	header("Location: ".$home_url);
}

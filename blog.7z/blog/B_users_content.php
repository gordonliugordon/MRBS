<?php
function users_content()
{
	?>
	<div class="menu">
		<a href="B_Index.php?target_page=users&user_info=1">Users Info</a>
		<hr>
		<a href="B_Index.php?target_page=users&user_need_approved=1">Users Need Approve</a>
		<hr>
	</div>
	<?php
	$obj = new Users();
	if ($_GET["user_info"] == 1) {
		if ($_SESSION["is_admin"] == 1) {
			?>
			<div class="menu_content">
				<table align="center" border="1px" cellspacing="0" cellpadding="5">
					<tr>
						<th>user_id</th>
						<th>user_name</th>
						<th>user_is_admin</th>
						<th>user_is_approved</th>
					</tr>
					<?php
					$result = $obj->listUsers($_SESSION['user_name']);
					foreach ($result as $item) {
						echo "<tr>
						<td>$item[0]</td>
						<td>$item[1]</td>
						<td>$item[2]</td>
						<td>$item[3]</td>
						</tr>";
					}
					?>
				</table>
			</div>
			<?php
		}
	} elseif ($_GET["user_need_approved"] == 1) {
		if (isset($_POST['approved_button'])) {
			if (!empty($_POST["admin"])) {
				foreach ($_POST["admin"] as $item) {
					$name = substr($item, 6);
					$result = $obj->updateUsers($name, 1);
				}
				foreach ($_POST["approved"] as $item) {
					$name = substr($item, 9);
					$result = $obj->updateUsers($name, 2);
				}
			} elseif (empty($_POST["admin"]) && !empty($_POST["approved"])) {
				foreach ($_POST["approved"] as $item) {
					$name = substr($item, 9);
					$result = $obj->updateUsers($name, 2);
				}
			}
			header("Location:B_Index.php?target_page=users&user_need_approved=1");
			unset($_POST["admin"]);
			unset($_POST["approved"]);
		}
		?>
		<div class="menu_content">
			<form method="post" name="listUserForm">
				<table align="center" border="1px" cellspacing="0" cellpadding="5">
					<tr>
						<th>user_name</th>
						<th>user_is_admin <br/>
							<input type='checkbox' id="check_all_admin" name="check_all_admin"
													  value='admin,admin'/>select all
						</th>
						<th>user_is_approved<br/>
							<input type='checkbox' id="check_all_approved"
														name="check_all_approved"
														value='approved,approved'/>select all
						</th>
					</tr>
					<?php
					$result = $obj->listUsers($_SESSION['user_name']);
					foreach ($result as $item) {
						if ($item[3] == 0) {
							echo "<tr>
						<td>{$item[1]}</td>
						<td>
						<input type='checkbox' class = 'check_admin'  name='admin[]' value='admin,$item[1]'/></td>
						<td>
						<input type='checkbox' class = 'check_approved' name='approved[]'  value='approved,$item[1]'/></td>
						</tr>";
						}
					}
					?>

				</table>
				<div align="center"><input type="submit" value="submit" name="approved_button"></div>
				<br/>
			</form>
		</div>
		<?php
	}
}
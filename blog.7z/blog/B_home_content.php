<?php
function home_content($search_text = "")
{
	$obj = new Articles();
	$target_page = $_GET['target_page'];

	$current_article_user_id = $_GET["current_article_user_id"]; // current article user id
	
	// =========== add comment part ============
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$comment_all_content = trim_input($_POST["comment_all_content"]);
		$user_id_all_content = $_SESSION["user_id"];
		$article_id_all_content = $_GET["current_article_id"];
		$comment_date_all_content = date('Y-m-d G-i-s');

		if (!empty($comment_all_content)) {
			$all_content_comment = new Comments();
			$is_cmted = $all_content_comment->addComment($comment_all_content, $comment_date_all_content, $user_id_all_content, $article_id_all_content);
			header("Location: ./B_Index.php?target_page=$target_page&current_article_id=$article_id_all_content&current_article_user_id=$current_article_user_id");
		}
	}
	
	?>
	<div style="margin: 5px 5%">
		<?php
		if (empty($search_text) && !isset($_GET["current_article_id"])) {
			// =========== no search part ============
			$date = date("Y-m-d G:i:sa");
			$total = $obj->countArticle("", $date)[0][0];
			$page = new Page($total, PAGE_SIZE);
			$limit = $page->limit;
			$attr = $obj->listArticles("", $date, $limit);

			if (!isset($_GET["current_article_id"])) {
				// =========== no search, list current day articles ============
				show_article_list($attr, $total, $page, $target_page);
			} else {
				// =========== no search, show article detail ============
				$cur_article_id = $_GET["current_article_id"];
				$arr = $obj->listArticles("", "", "", "", $cur_article_id);
				$list_all_comment = new Comments();
				$comment_lists = $list_all_comment->listLatestComment($cur_article_id);
				show_article_page($arr, $comment_lists);
			}
		} else {
			// =========== search part ============
			$total = $obj->countArticle($search_text)[0][0];
			$page = new Page($total, PAGE_SIZE);
			$limit = $page->limit;
			$attr = $obj->listArticles($search_text, "", $limit);

			// =========== search part, show search result article detail ============
			if (isset($_GET["current_article_id"]) && empty($search_text)) {
				$cur_article_id = $_GET["current_article_id"];
				$arr = $obj->listArticles("", "", "", "", $cur_article_id);
				$list_all_comment = new Comments();
				$comment_lists = $list_all_comment->listLatestComment($cur_article_id);
				show_article_page($arr, $comment_lists);
			} else {
				// =========== search part, list search result articles ============
				show_article_list($attr, $total, $page, $target_page);
			}
		}
		?>
	</div>
	<?php
}
<?php

function show_article_list($attr, $total, $page, $target_page)
{
	foreach ($attr as $item) {
		?>
		<div class="article_list">
			<h1>
				<?php echo toHTML($item[1]); ?>
			</h1>
			<p class="article_des"><?php echo "&nbsp" . "&nbsp" . $item[5] . "&nbsp" . "&nbsp" .
					"&nbsp" . "&nbsp" . $item[3] . " <br/>"; ?></p>
			<p><?php echo toHTML(substr($item[2], 0, 40)) . " ..."; ?></p>
			<div class="blog_show_link">
				<?php
				if ($target_page == 'my') {
					?>
					<a href="./B_Index.php?target_page=my&choose=all_my_article&article_id=<?php
					echo $item[0];
					?>">Read more</a>
					<?php
				} else {
					?>
					<a href="./B_Index.php?target_page=<?php
					echo $target_page;
					?>&current_article_id=<?php
					echo $item[0];
					?>&current_article_user_id=<?php
					echo $item[4];
					?>">Read more</a>
					<?php
				}
				?>

			</div>
		</div>
		<br/>
		<?php
	}
	?>
	<div>
		<?php
		if ($total >= 20) {
			echo $page->fpage();
		}
		?>
	</div>
	<?php
}

function show_article_detail($arr)
{
	foreach ($arr as $item) {
		?>
		<div class="article_list">
			<h1>
				<?php echo toHTML($item[1]); ?>
			</h1>
			<p class="article_des"><?php echo "&nbsp" . "&nbsp" . $item[5] . "&nbsp" . "&nbsp" .
					"&nbsp" . "&nbsp" . $item[3] . " <br/>"; ?></p>
			<p><?php echo toHTML($item[2]); ?></p>
		</div>
		<?php
	}
}

function add_comment_form($current_article_user_id, $current_logged_user_id)
{
	// =========== user id == article user id, do not show comment form! ===========
	if ($current_article_user_id != $current_logged_user_id) {
		?>
		<div class="article_show">
			<!-- here is add comment part!-->
			<form class="" method="post" action="">
				<div class="blog_show_comment_tip">Comment :</div>
					<textarea name="comment_all_content" cols="67" rows="10"
							  placeholder="Type comment here ..."></textarea>
				<br/>
				<button type="submit" name="submit_all_content">Release Now!</button>
			</form>
		</div>
		<?php
	}
}

function show_article_comment($comment_lists)
{
	?>
	<!-- =========== always show this line for comment lists start ============ -->
	<div class="blog_show_comment_start">*** comment lists ***</div>
	<!-- =========== list comments part ============ -->
	<div>
		<?php
		// =========== list comments part ============
		foreach ($comment_lists as $comment_list) {
			$comment_text[] = toHTML($comment_list[1]);
			$comment_created_date[] = $comment_list[2];
			$comment_user[] = $comment_list[5];
		}

		for ($i = 0; $i < count($comment_text); $i++) {
			?>
			<div class="blog_show_comment">
				<p>
					<?php echo $comment_text[$i]; ?>
				</p>
				<div class="blog_show_comment_info">
					<?php
					$temp_user = $comment_user[$i] == null ? "Anonymous" : $comment_user[$i];
					echo $temp_user . " comment at " . $comment_created_date[$i];
					?>
				</div>
			</div>
			<?php
		}
		?>
	</div>
	<?php
}

function show_article_page($arr, $comment_lists)
{
	$current_article_user_id = $_GET["current_article_user_id"]; // current article user id
	$current_logged_user_id = $_SESSION["user_id"]; // logged user id

	show_article_detail($arr);

	add_comment_form($current_article_user_id, $current_logged_user_id);

	show_article_comment($comment_lists);

}
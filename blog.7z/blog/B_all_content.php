<?php
function all_content()
{
	$obj = new Articles();
	$total = $obj->countArticle()[0][0];
	$page = new Page($total, PAGE_SIZE);
	$limit = $page->limit;
	$cur_article_id = $_GET["current_article_id"];
	$target_page = $_GET['target_page'];

	$attr = $obj->listArticles("", "", $limit);

	$arr = $obj->listArticles("", "", "", "", $cur_article_id);

	$list_all_comment = new Comments();
	$comment_lists = $list_all_comment->listLatestComment($cur_article_id);

	$current_article_user_id = $_GET["current_article_user_id"]; // current article user id

	// =========== add comment part ============
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$comment_all_content = trim_input($_POST["comment_all_content"]);
		$user_id_all_content = $_SESSION["user_id"];
		$article_id_all_content = $_GET["current_article_id"];
		$comment_date_all_content = date('Y-m-d G-i-s');

		if (!empty($comment_all_content)) {
			$all_content_comment = new Comments();
			$is_cmted = $all_content_comment->addComment($comment_all_content, $comment_date_all_content, $user_id_all_content, $article_id_all_content);
			header("Location: ./B_Index.php?target_page=$target_page&current_article_id=$article_id_all_content&current_article_user_id=$current_article_user_id");
		}
	}

	?>
	<div style="margin: 5px 5%">
		<?php
		if (!isset($_GET["current_article_id"])) {
			// ========= show article list =========
			show_article_list($attr, $total, $page, $target_page);
		} else {
			// ========= show one article detail =========
			show_article_page($arr, $comment_lists);
		}
		?>
	</div>
	<?php
}
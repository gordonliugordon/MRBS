<?php
define("DB_HOST","localhost");
define("DB_USER_NAME","root");
define("DB_USER_PASSWORD","root");
define("DB_NAME","blog");
define('PAGE_SIZE',20); // article numbers in each page